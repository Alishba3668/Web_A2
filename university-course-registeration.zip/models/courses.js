const mongoose = require("mongoose");

const CourseSchema = new mongoose.Schema({
    name: { type: String, required: true },
    code: { type: String, required: true, unique: true },
    department: { type: String, required: true },
    credits: { type: Number, required: true },
    prerequisites: [{ type: mongoose.Schema.Types.ObjectId, ref: "Course" }],
    seatsAvailable: { type: Number, required: true },
});

module.exports = mongoose.model("Course", CourseSchema);
