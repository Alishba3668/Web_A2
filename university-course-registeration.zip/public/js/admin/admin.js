document.addEventListener("DOMContentLoaded", () => {
    console.log("Admin dashboard loaded.");
});
