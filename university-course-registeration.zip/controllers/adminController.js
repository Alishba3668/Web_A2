const Course = require('../models/courses'); // Change 'course' to 'courses'



const User = require('../models/user');

exports.getDashboard = (req, res) => {
    res.render('admin/dashboard', { admin: req.user });
};

exports.getManageCourses = async (req, res) => {
    const courses = await Course.find();
    res.render('admin/manageCourses', { courses });
};

exports.getManageStudents = async (req, res) => {
    const students = await User.find({ role: 'student' });
    res.render('admin/manageStudents', { students });
};
