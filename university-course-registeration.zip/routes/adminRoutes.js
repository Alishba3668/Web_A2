const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const authMiddleware = require('../middleware/auth'); // Match existing file


router.get('/dashboard', authMiddleware.adminAuth, adminController.getDashboard);
router.get('/manageCourses', authMiddleware.adminAuth, adminController.getManageCourses);
router.get('/manageStudents', authMiddleware.adminAuth, adminController.getManageStudents);

module.exports = router;
